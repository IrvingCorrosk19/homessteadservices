import sharp from "sharp";

const session = process.env.CONTROL_SESSION;
const csrf = process.env.CONTROL_CSRF;
if (!session || !csrf) {
  console.error("missing CONTROL_SESSION/CONTROL_CSRF");
  process.exit(2);
}

const form = new FormData();
form.set("note", "fisica ui r2");
form.set("publishMode", "album");
form.set("batchKey", `fisica-${Date.now()}`);
for (const bg of [
  { r: 12, g: 88, b: 140 },
  { r: 140, g: 48, b: 24 },
  { r: 32, g: 120, b: 64 },
]) {
  const b = await sharp({ create: { width: 1080, height: 1350, channels: 3, background: bg } })
    .jpeg()
    .toBuffer();
  form.append("files", new Blob([b], { type: "image/jpeg" }), "f.jpg");
}

const r = await fetch("http://127.0.0.1:3000/api/admin/content/intake", {
  method: "POST",
  headers: {
    Authorization: `Bearer ${session}`,
    "X-Homestead-Client": "control-mobile",
    "X-CSRF-Token": csrf,
  },
  body: form,
});
const j = await r.json();
const id = j.publicId || j.items?.[0]?.publicId;
if (!id) {
  console.error(JSON.stringify(j));
  process.exit(1);
}
for (let i = 0; i < 60; i++) {
  const d = await fetch(`http://127.0.0.1:3000/api/admin/content/jobs/${id}`, {
    headers: { Authorization: `Bearer ${session}`, "X-Homestead-Client": "control-mobile" },
  }).then((x) => x.json());
  const st = String(d.job?.status || d.status || "");
  if (["AWAITING_APPROVAL", "APPROVED", "NEEDS_REVIEW"].includes(st)) break;
  await new Promise((r) => setTimeout(r, 400));
}
process.stdout.write(String(id));
