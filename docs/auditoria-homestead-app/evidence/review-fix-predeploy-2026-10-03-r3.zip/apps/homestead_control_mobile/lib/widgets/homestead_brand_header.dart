import "package:flutter/material.dart";

import "../theme/homestead_theme.dart";

/// Official Homestead wordmark / mark for login and home.
class HomesteadBrandHeader extends StatelessWidget {
  const HomesteadBrandHeader({
    super.key,
    this.showWordmark = true,
    this.compact = false,
    this.subtitle,
  });

  final bool showWordmark;
  final bool compact;
  final String? subtitle;

  @override
  Widget build(BuildContext context) {
    final logoH = compact ? 56.0 : 88.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.asset(
          showWordmark ? "assets/branding/homestead-logo-full.png" : "assets/branding/homestead-mark.png",
          height: logoH,
          fit: BoxFit.contain,
          alignment: Alignment.centerLeft,
          filterQuality: FilterQuality.high,
          errorBuilder: (_, __, ___) => Text(
            "HOMESTEAD",
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: HomesteadColors.navy,
                  fontWeight: FontWeight.w800,
                ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          "Homestead Control",
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: HomesteadColors.accentDeep,
                fontWeight: FontWeight.w700,
              ),
        ),
        if (subtitle != null) ...[
          const SizedBox(height: 8),
          Text(
            subtitle!,
            style: const TextStyle(color: HomesteadColors.charcoal, height: 1.4),
          ),
        ],
      ],
    );
  }
}
