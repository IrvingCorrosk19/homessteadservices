import "package:intl/intl.dart";

DateTime panamaNow() => DateTime.now().toUtc().subtract(const Duration(hours: 5));

String panamaTodayIso() => DateFormat("yyyy-MM-dd").format(panamaNow());

String formatPanamaNow() {
  final now = panamaNow();
  return "${DateFormat("EEEE d MMM yyyy · HH:mm", "es_PA").format(now)} (Panamá)";
}

String formatPanamaIso(String? iso) {
  if (iso == null || iso.isEmpty) return "—";
  final parsed = DateTime.tryParse(iso);
  if (parsed == null) return iso;
  final panama = parsed.toUtc().subtract(const Duration(hours: 5));
  return DateFormat("d MMM yyyy · HH:mm", "es_PA").format(panama);
}

String formatPanamaDate(DateTime d) => DateFormat("EEEE d MMM yyyy", "es_PA").format(d);

String formatPanamaMonth(DateTime d) {
  final text = DateFormat("MMMM yyyy", "es_PA").format(d);
  if (text.isEmpty) return text;
  return "${text[0].toUpperCase()}${text.substring(1)}";
}

String isoDate(DateTime d) =>
    "${d.year.toString().padLeft(4, "0")}-${d.month.toString().padLeft(2, "0")}-${d.day.toString().padLeft(2, "0")}";
