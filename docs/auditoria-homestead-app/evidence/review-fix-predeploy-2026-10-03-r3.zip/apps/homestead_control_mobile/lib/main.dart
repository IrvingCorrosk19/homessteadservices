import "package:flutter/material.dart";
import "package:intl/intl.dart";
import "package:intl/date_symbol_data_local.dart";
import "package:provider/provider.dart";

import "config.dart";
import "screens/shell_screen.dart";
import "screens/login_screen.dart";
import "state/session_controller.dart";
import "theme/homestead_theme.dart";
import "widgets/homestead_brand_header.dart";

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting("es_PA");
  Intl.defaultLocale = "es_PA";
  runApp(const HomesteadControlApp());
}

class HomesteadControlApp extends StatelessWidget {
  const HomesteadControlApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => SessionController()..bootstrap(),
      child: MaterialApp(
        title: kAppName,
        debugShowCheckedModeBanner: false,
        theme: buildHomesteadTheme(),
        home: const _RootGate(),
      ),
    );
  }
}

class _RootGate extends StatelessWidget {
  const _RootGate();

  @override
  Widget build(BuildContext context) {
    final session = context.watch<SessionController>();
    if (session.booting) {
      return Scaffold(
        backgroundColor: HomesteadColors.cream,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.asset(
                "assets/branding/homestead-logo-full.png",
                height: 96,
                errorBuilder: (_, __, ___) => const HomesteadBrandHeader(compact: true),
              ),
              const SizedBox(height: 20),
              const Text(
                "Homestead Control",
                style: TextStyle(
                  color: HomesteadColors.navy,
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 24),
              const CircularProgressIndicator(),
            ],
          ),
        ),
      );
    }
    if (!session.isAuthenticated) return const LoginScreen();
    return const ShellScreen();
  }
}
